package com.example.feinapps;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

public class MenuActivity extends AppCompatActivity {

    AppCompatImageButton btnOpenMain, btnOpenMaps, btnOpenInstagram, btnOpenWhatsApp, btnOpenProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Inisialisasi tombol
        btnOpenMain = findViewById(R.id.btn_open_main);
        btnOpenMaps = findViewById(R.id.btn_open_maps);
        btnOpenInstagram = findViewById(R.id.btn_open_instagram);
        btnOpenWhatsApp = findViewById(R.id.btn_open_whatsapp);
        btnOpenProfile = findViewById(R.id.btn_open_profile); // Pastikan ID ini ada di XML

        // Menu ke MainActivity
        btnOpenMain.setOnClickListener(v -> {
            startActivity(new Intent(MenuActivity.this, MainActivity.class));
        });

        // Menu ke Google Maps
        btnOpenMaps.setOnClickListener(v -> {
            Uri geoUri = Uri.parse("geo:0,0?q=Universitas+Muhammadiyah+Ponorogo");
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, geoUri);
            mapIntent.setPackage("com.google.android.apps.maps");

            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                // fallback ke browser jika Maps tidak tersedia
                Intent fallbackIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("geo:0,0?q=Universitas+Muhammadiyah+Ponorogo"));
                startActivity(fallbackIntent);
            }

        });

        // Menu ke Instagram
        btnOpenInstagram.setOnClickListener(v -> {
            String username = "fmbrihrs_";
            Uri uri = Uri.parse("https://instagram.com/" + username);
            Intent instagramIntent = new Intent(Intent.ACTION_VIEW, uri);
            instagramIntent.setPackage("com.instagram.android");

            if (instagramIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(instagramIntent);
            } else {
                startActivity(new Intent(Intent.ACTION_VIEW, uri)); // fallback ke browser
            }
        });

        // Menu ke WhatsApp
        btnOpenWhatsApp.setOnClickListener(v -> {
            String phoneNumber = "6289635543381";
            String message = "Halo, saya tertarik dengan proyek Anda!";
            String url = "https://wa.me/" + phoneNumber + "?text=" + Uri.encode(message);

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.whatsapp");

            try {
                startActivity(intent);
            } catch (Exception e) {
                // fallback ke browser jika WhatsApp tidak ada
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        });

        // Menu ke ProfileActivity
        btnOpenProfile.setOnClickListener(v -> {
            startActivity(new Intent(MenuActivity.this, ProfileActivity.class));
        });
    }
}
