package com.example.feinapps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edtLength, edtWidth, edtHeight;
    Button btnCalculate;
    TextView tvResult;

    private static final String STATE_RESULT = "state_result";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtLength = findViewById(R.id.edt_length);
        edtWidth = findViewById(R.id.edt_width);
        edtHeight = findViewById(R.id.edt_height);
        btnCalculate = findViewById(R.id.btn_calculate);
        tvResult = findViewById(R.id.tv_result);

        btnCalculate.setOnClickListener(this);

        if (savedInstanceState != null) {
            String result = savedInstanceState.getString(STATE_RESULT);
            tvResult.setText(result);
        }
    }

    @Override
    public void onClick(View v) {
        String inputLength = edtLength.getText().toString().trim();
        String inputWidth = edtWidth.getText().toString().trim();
        String inputHeight = edtHeight.getText().toString().trim();

        boolean isEmptyFields = false;

        if (inputLength.isEmpty()) {
            isEmptyFields = true;
            edtLength.setError("Tidak boleh kosong");
        }
        if (inputWidth.isEmpty()) {
            isEmptyFields = true;
            edtWidth.setError("Tidak boleh kosong");
        }
        if (inputHeight.isEmpty()) {
            isEmptyFields = true;
            edtHeight.setError("Tidak boleh kosong");
        }

        if (!isEmptyFields) {
            try {
                double length = Double.parseDouble(inputLength);
                double width = Double.parseDouble(inputWidth);
                double height = Double.parseDouble(inputHeight);
                double volume = length * width * height;
                tvResult.setText(String.valueOf(volume));
            } catch (NumberFormatException e) {
                tvResult.setText("Input tidak valid");
            }
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(STATE_RESULT, tvResult.getText().toString());
    }
}
